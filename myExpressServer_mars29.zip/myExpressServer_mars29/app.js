import express from "express";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";

// Rest
// 1. Använd get för att läsa, post för att skapa, put för att uppdatera
// och delete för att ta bort.
// 2. Använd resurs-namn i sökvägarna i plural. Använd aldrig verb i sökvägar.

const app = express();
const PORT = 5001;

app.use(bodyParser.json());
app.use(cookieParser());

let todos = [];

function logTimeMiddleWare(req, res, next) {
  console.log("Time now: ", new Date());
  next();
}

function setHelloWorld(req, res, next) {
  req.message = "Hello world";
  next();
}

app.use(logTimeMiddleWare);
app.use(setHelloWorld);

app.get("/", (req, res) => {
  console.log("Message from middleware: ", req.message);

  console.log("All cookies: ", req.cookies);
  console.log("myCookie", req.cookies.myCookie);

  console.log(req.headers);

  res.cookie("myCookie", "hej", { maxAge: 900000000, httpOnly: false });

  console.log("received get request");
  res.send("hello world from express 2");
});

app.post("/todos", (req, res) => {
  console.log("In post. Message from middleware: ", req.message);
  const data = req.body;
  todos.push(data);

  console.log("todos", todos);

  res.send(
    "Post data received: " + data.title + " " + data.done + " " + data.id
  );
});

app.put("/todos/:id", (req, res) => {
  const id = req.params.id;
  const data = req.body;

  for (let i = 0; i < todos.length; i++) {
    const todo = todos[i];
    if (id == todo.id) {
      todos[i] = data;
    }
  }

  console.log("todos updated", todos);
  res.send("done");
});

app.delete("/todos/:id", (req, res) => {
  const id = req.params.id;

  todos = todos.filter((todo) => {
    return todo.id != id;
  });
  res.send("done");
});

app.listen(PORT, () => {
  console.log("Express server started listening on port " + PORT);
});
