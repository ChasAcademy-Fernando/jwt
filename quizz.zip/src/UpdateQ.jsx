import { useState } from "react"

export default function({question}){

const [title,setTitle] = useState()

function handleUpdate(){
    const question ={
        title,
    }
    updateQuestion(question)
}

return(
    <div>
        <input value={question.title} type="text" onClick={(e) =>{setTitle(e.target.value)} } />

        <button onClick={handleUpdate}>Update</button>
    </div>
)

}