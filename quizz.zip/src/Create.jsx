import { setQuiz, useQuiz} from "./redux/quizz";
import { useState } from "react";

export default function Create() {
    const [title, setTitle] = useState();
    const [corAns, setcorAns] = useState();
    const [answers, setAnswers] = useState([]);
   
     /* title: "Vad heter huvudstaden i Sverige?",
  answers:["Malmö",
  "Göteborg",
  "Stockholm",],
  correctAnswer: 2,
  id: 1,*/
    function handleAddQuestion() {
      const question = {
        title,
        ...answers,
        corAns,
        id: Date.now(),
      };
      setQuiz(question);
      console.log(answers);
    }
  
    return (
      <div className="">
        <h2>Create new Question</h2>
  
        <label>Title</label>
        <input type="text" onChange={(e) => setTitle(e.target.value)} />
  
        <label>Answers 1</label>
        <input type="text" onChange={(e) => setAnswers(answers => [...answers, e.target.value])} />
  
        <label>Answers 2</label>
        <input type="text" onChange={(e) => setAnswers(answers => [...answers, e.target.value])} />
        
        <label>Answers 3</label>
        <input type="text" onChange={(e) => setAnswers(answers => [...answers, e.target.value])} />
        
        <label>What is the correct answer?</label>
        <input type="text" onChange={(e) => setcorAns(e.target.value -1)} />
  
        <button onClick={handleAddQuestion}>Add Question</button>
      </div>
    );
  }
  