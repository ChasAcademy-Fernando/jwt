// Redux funktioner (Reducers) som behövs.
// 1. addQuestion
// 2. updateQuestion
// 3. deleteQuestion

// 4. startQuizz ->
// sätt quizzStated = true, showResult = false,
// currentQuestion = 0, score = 0

// 5. answerQuestion ->
// kolla om det var rätt svar då öka score med 1
// kolla om det var sista frågan (Kolla om
//    currentQuestion är == questions.length - 1)
//    då ändra showResult = true.
// Öka currentQuestion med 1.

// Data för frågorna och quizzet:

import { createReduxModule } from "hooks-for-redux";

const initialState = {
  quizzStated: false,
  showResult: false,
  currentQuestion: 0,
  score: 0,
  questions: [
    {
      title: "Vad heter huvudstaden i Sverige?",
      answers:["Malmö",
      "Göteborg",
      "Stockholm",],
      correctAnswer: 2,
      id: 1,
    },
    {
      title: "Vad heter huvudstaden i Sverige??",
       answers: ["Malmö",
      "Göteborg",
      "Stockholm"],
      correctAnswer: 2,
      id: 2,
    },
    {
      title: "Vad heter huvudstaden i Sverige??",
       answers: ["Malmö",
      "Göteborg",
      "Stockholm"],
      correctAnswer: 2,
      id: 3,
    },
  ],
};


export const [useQuiz, { setQuiz, removeQuiz, setStarted, setResult,setScore, setQuest}] =
  createReduxModule("Quizzes", initialState, {
    setQuiz: (state,quiz) => {
      console.log("sdlnlkflsak");
      return { ...state, questions:quiz}
      
    },
    removeQuiz: (state, objectID) => {
      return {
        ...state,
        questions: state.questions.filter(
          (questions) => questions.objectID !== objectID
        ),
      };
    },

    setStarted: (state, started) =>{
    return{
      ...state, quizzStated:started
    }
    },
    setScore: (state,score) => {
      return{...state, score: score+1}
    },
    
    setQuest: (state,currentQuestion) =>{
  	return {...state, currentQuestion: currentQuestion+1 }
    

    }
    
    
    },
    );


